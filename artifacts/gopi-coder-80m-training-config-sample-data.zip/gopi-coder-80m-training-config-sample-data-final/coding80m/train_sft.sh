#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
PYTHON="${PYTHON:-.venv/bin/python}"; [[ -x "$PYTHON" ]] || PYTHON=python
export PYTHONPATH="${PYTHONPATH:-}:src"

MODE="${1:-auto}"
LATEST="checkpoints/coding80m/sft/latest.pt"
INIT="checkpoints/coding80m/pretrain-stage2/best.pt"

case "$MODE" in
  auto)
    if [[ -s "$LATEST" ]]; then
      echo "[sft] Resume checkpoint found: $LATEST"
      exec "$PYTHON" scripts/train.py \
        --model-config configs/coding80m/model.yaml \
        --training-config configs/coding80m/finetuning.sft.yaml \
        --resume "$LATEST"
    fi
    [[ -s "$INIT" ]] || { echo "[sft] Missing Stage 2 best checkpoint: $INIT" >&2; exit 2; }
    echo "[sft] Starting new stage from: $INIT"
    exec "$PYTHON" scripts/train.py \
      --model-config configs/coding80m/model.yaml \
      --training-config configs/coding80m/finetuning.sft.yaml \
      --init-from "$INIT"
    ;;
  resume)
    [[ -s "$LATEST" ]] || { echo "[sft] Cannot resume: $LATEST not found" >&2; exit 2; }
    exec "$PYTHON" scripts/train.py \
      --model-config configs/coding80m/model.yaml \
      --training-config configs/coding80m/finetuning.sft.yaml \
      --resume "$LATEST"
    ;;
  fresh)
    [[ ! -e "$LATEST" ]] || { echo "[sft] Refusing fresh start while $LATEST exists" >&2; exit 2; }
    [[ -s "$INIT" ]] || { echo "[sft] Missing Stage 2 best checkpoint: $INIT" >&2; exit 2; }
    exec "$PYTHON" scripts/train.py \
      --model-config configs/coding80m/model.yaml \
      --training-config configs/coding80m/finetuning.sft.yaml \
      --init-from "$INIT"
    ;;
  *) echo "Usage: $0 [auto|resume|fresh]" >&2; exit 2;;
esac
