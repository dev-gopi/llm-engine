#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
PYTHON="${PYTHON:-.venv/bin/python}"; [[ -x "$PYTHON" ]] || PYTHON=python
export PYTHONPATH="${PYTHONPATH:-}:src"
rm -rf data/coding80m/tokenizer
"$PYTHON" scripts/tokenize.py train --config configs/coding80m/tokenizer.yaml
"$PYTHON" coding80m/verify_vocab.py
