# Production data targets

| Stage | Recommended target |
|---|---:|
| Tokenizer training | 5-20 GB representative code + docs |
| Pretraining stage 1 | 1.0-1.5B tokens |
| Pretraining stage 2 | 0.4-0.8B tokens |
| SFT | 100K-250K high-quality conversations |
| Agent trajectories | 20K-60K validated trajectories |
| DPO | 20K-80K preference pairs |

Suggested code languages: Python 24%, TypeScript/JavaScript 22%, Java 12%, Go 10%, C/C++ 10%, Rust 6%, SQL 6%, Shell 4%, other 6%. Adjust for the coding domains you actually need.

Prefer quality and provenance over raw quantity. Repository-level train/validation/test splitting is important to reduce leakage.
