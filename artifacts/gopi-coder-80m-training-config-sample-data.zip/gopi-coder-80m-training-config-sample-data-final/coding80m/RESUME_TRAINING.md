# GopiCoder-80M resumable training

The main `scripts/train.py` already stores model, optimizer, scheduler, scaler,
RNG/trainer state, `current_epoch` and `batch_in_epoch`. The updated stage
wrappers automatically use `latest.pt` when it exists.

## One-time installation for DPO mid-epoch resume

The stock DPO trainer saves at epoch boundaries. Install the included compatible
patch so it also saves every `checkpoint_every` steps and remembers the batch
offset:

```bash
./coding80m/install_resume_support.sh
```

A timestamped backup of the two replaced project files is created under
`.resume-support-backups/`.

## Normal use: auto resume

Run any stage normally:

```bash
./coding80m/train_stage1.sh
./coding80m/train_stage2.sh
./coding80m/train_sft.sh
./coding80m/train_dpo.sh
```

Default mode is `auto`:

- if the stage's `latest.pt` exists, it runs with `--resume latest.pt`;
- otherwise it starts the stage correctly from scratch / the previous stage's
  `best.pt`.

If the machine reboots, CUDA crashes, SSH closes, or you stop training, run the
same command again. It resumes from the most recent saved checkpoint.

### Explicit modes

```bash
./coding80m/train_stage1.sh auto
./coding80m/train_stage1.sh resume
./coding80m/train_stage1.sh fresh
```

`fresh` intentionally refuses to overwrite an existing `latest.pt`. Archive or
move the old stage checkpoint directory yourself before intentionally restarting.
This prevents accidental loss of days of training.

## Entire pipeline

```bash
./coding80m/train_all.sh
```

This executes Stage 1 -> Stage 2 -> SFT -> DPO. Re-running it after interruption
is safe: every stage auto-resumes its own `latest.pt`. DPO is skipped if the
preference training file is absent/empty.

## Status

```bash
./coding80m/training_status.sh
```

It shows which latest/best checkpoints exist and the last useful log event.

## Checkpoint intervals

Stage 1 / Stage 2 / SFT already use their configured `checkpoint_every` values.
DPO now uses:

```yaml
checkpoint_every: 250
```

A hard power loss can only resume from the *last saved checkpoint*, so at most
one checkpoint interval of work can be lost. Lower the interval if that recovery
window is too large, at the cost of more checkpoint I/O.

## Important: resume vs init-from

- `--resume`: continue the *same* training stage, including optimizer/scheduler
  and trainer position.
- `--init-from`: start a *new* stage using only the previous stage's model
  weights.

Do not use `--init-from` to recover an interrupted stage.
