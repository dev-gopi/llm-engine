# GopiCoder 80M training bundle

Drop this bundle into the root of the hardened `llm-engine` repository.

## Architecture
- 81,808,128 parameters
- 8,192-token code-aware byte-level BPE
- 12 decoder layers, hidden size 768
- 12 query heads / 4 KV heads (GQA)
- SwiGLU FFN 2,048
- RoPE, RMSNorm, 2,048-token maximum context
- tied input/output embeddings and gradient checkpointing

## Important: sample data vs real training data
The included data is synthetic **sample data** for validating formats, tokenizer creation, loaders, and the training pipeline. It is not enough to make an 80M model a strong coding agent.

For a serious run, keep these schemas/paths but replace or expand the corpora with reviewed, licensed data. A useful target is roughly 1.4-2.2B total pretraining tokens, then 100K-250K high-quality SFT examples, 20K-60K agent/tool trajectories, and 20K-80K preference pairs. Keep benchmark test sets out of training.

Recommended pretraining mixture: 50-60% permissively licensed source code, 15-20% technical docs, 10-15% clean general text/reasoning, 15-25% code transformed for fill-in-the-middle. Deduplicate by file/repository and near-duplicate content, remove generated/vendor/minified files, secrets and PII, and preserve license/provenance metadata.

## Run order
```bash
source .venv/bin/activate
python coding80m/preflight.py
./coding80m/run_tokenizer.sh
./coding80m/inspect.sh
./coding80m/train_stage1.sh
./coding80m/train_stage2.sh
./coding80m/train_sft.sh
# Optional preference alignment after SFT:
./coding80m/train_dpo.sh
./coding80m/report.sh
./coding80m/serve.sh
```

### Why two pretraining stages?
Stage 1 trains broad code and technical-language competence at 1,024 tokens with a 3e-4 peak LR. Stage 2 continues from the best Stage-1 checkpoint at the full 2,048-token context and shifts the mixture toward code/FIM with a lower 1.5e-4 LR. SFT then learns assistant behavior and tool/agent trajectories at 2e-5. DPO is optional and deliberately conservative at 5e-6.

## Real-data quality gates
Do not promote a checkpoint only because train loss is low. Require validation loss, held-out code generation, compile/test pass rate, tool-call validity, regression tests, repetition rate, and contamination checks. HumanEval/MBPP/SWE-bench-style evaluation examples should stay evaluation-only.

## Hardware notes
BF16 configs assume a BF16-capable CUDA GPU. If your GPU does not support BF16, switch `mixed_precision` to `fp16`. Effective batches are intentionally achieved with gradient accumulation. Multi-GPU runs can use the project's DDP support; DPO CLI is single-device in the current codebase.


## Resume after interruption

See `coding80m/RESUME_TRAINING.md`. The stage scripts now auto-resume from `latest.pt`.
