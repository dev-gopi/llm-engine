from pathlib import Path
import sys, yaml
sys.path.insert(0, 'src')
from tokenizer.encoder import Tokenizer
model = yaml.safe_load(Path('configs/coding80m/model.yaml').read_text())
tok = Tokenizer.load(Path('data/coding80m/tokenizer'))
expected = int(model['vocab_size'])
if tok.vocab_size != expected:
    raise SystemExit(f'VOCAB CHECK FAILED: tokenizer={tok.vocab_size}, model={expected}')
print(f'VOCAB CHECK: PASS (tokenizer={tok.vocab_size}, model={expected})')
