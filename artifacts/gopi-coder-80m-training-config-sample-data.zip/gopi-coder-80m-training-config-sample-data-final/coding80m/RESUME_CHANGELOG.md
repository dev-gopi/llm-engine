# Resume support changelog

- Stage 1: auto-resume from `checkpoints/coding80m/pretrain-stage1/latest.pt`.
- Stage 2: auto-resume its own `latest.pt`; only a fresh stage initializes from Stage 1 `best.pt`.
- SFT: auto-resume its own `latest.pt`; only a fresh stage initializes from Stage 2 `best.pt`.
- DPO: auto-resume its own `latest.pt`; only a fresh stage initializes from SFT `best.pt`.
- DPO core patch: periodic `checkpoint_every` save plus `batch_in_epoch` state for mid-epoch recovery.
- `train_all.sh`: sequential auto-resumable pipeline.
- `training_status.sh`: quick checkpoint/log status.
- Fresh mode refuses to overwrite an existing checkpoint.
