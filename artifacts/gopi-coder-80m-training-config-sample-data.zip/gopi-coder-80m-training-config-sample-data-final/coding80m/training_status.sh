#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
PYTHON="${PYTHON:-.venv/bin/python}"; [[ -x "$PYTHON" ]] || PYTHON=python
export PYTHONPATH="${PYTHONPATH:-}:src"

printf '%-10s %-9s %-10s %-14s %s\n' "STAGE" "LATEST" "BEST" "LATEST SIZE" "LAST LOG EVENT"
printf '%-10s %-9s %-10s %-14s %s\n' "----------" "---------" "----------" "--------------" "------------------------------"
show_stage() {
  local name="$1" dir="$2" log="$3"
  local latest="$dir/latest.pt" best="$dir/best.pt"
  local latest_state="missing" best_state="missing" size="-" event="-"
  if [[ -s "$latest" ]]; then latest_state="yes"; size=$(du -h "$latest" | awk '{print $1}'); fi
  [[ -s "$best" ]] && best_state="yes"
  if [[ -f "$log" ]]; then
    event=$(grep -E 'epoch=.*step=|validation .*step=|dpo epoch=.*step=|checkpoint kind=' "$log" | tail -1 || true)
    [[ -n "$event" ]] || event=$(tail -1 "$log" 2>/dev/null || true)
  fi
  printf '%-10s %-9s %-10s %-14s %s\n' "$name" "$latest_state" "$best_state" "$size" "$event"
}
show_stage stage1 checkpoints/coding80m/pretrain-stage1 logs/coding80m-pretrain-stage1.log
show_stage stage2 checkpoints/coding80m/pretrain-stage2 logs/coding80m-pretrain-stage2.log
show_stage sft checkpoints/coding80m/sft logs/coding80m-sft.log
show_stage dpo checkpoints/coding80m/dpo logs/coding80m-dpo.log
