#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")/.."

PYTHON="${PYTHON:-.venv/bin/python}"
if [[ ! -x "$PYTHON" ]]; then
  PYTHON="python"
fi

STAGE="${1:-stage1}"

case "$STAGE" in

  stage1)
    LOG="logs/coding80m-pretrain-stage1.log"
    OUTPUT="reports/coding80m/pretrain-stage1.json"
    TRAINING_CONFIG="configs/coding80m/pretraining.stage1.yaml"
    LATEST="checkpoints/coding80m/pretrain-stage1/latest.pt"
    BEST="checkpoints/coding80m/pretrain-stage1/best.pt"
    ;;

  stage2)
    LOG="logs/coding80m-pretrain-stage2.log"
    OUTPUT="reports/coding80m/pretrain-stage2.json"
    TRAINING_CONFIG="configs/coding80m/pretraining.stage2.yaml"
    LATEST="checkpoints/coding80m/pretrain-stage2/latest.pt"
    BEST="checkpoints/coding80m/pretrain-stage2/best.pt"
    ;;

  sft)
    LOG="logs/coding80m-sft.log"
    OUTPUT="reports/coding80m/sft.json"
    TRAINING_CONFIG="configs/coding80m/finetuning.sft.yaml"
    LATEST="checkpoints/coding80m/sft/latest.pt"
    BEST="checkpoints/coding80m/sft/best.pt"
    ;;

  *)
    echo "Usage: $0 {stage1|stage2|sft}"
    exit 1
    ;;

esac

if [[ ! -f "$LOG" ]]; then
  echo "Training log not found: $LOG"
  echo "Start that training stage first."
  exit 1
fi

mkdir -p "$(dirname "$OUTPUT")"

"$PYTHON" scripts/build_training_report.py \
  --log "$LOG" \
  --output "$OUTPUT" \
  --model-config configs/coding80m/model.yaml \
  --training-config "$TRAINING_CONFIG" \
  --latest-checkpoint "$LATEST" \
  --best-checkpoint "$BEST"

echo
echo "Report written to: $OUTPUT"
