#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
PYTHON="${PYTHON:-.venv/bin/python}"; [[ -x "$PYTHON" ]] || PYTHON=python
export PYTHONPATH="${PYTHONPATH:-}:src"

echo "=== GopiCoder-80M resumable training pipeline ==="
echo "Each stage auto-resumes from its latest.pt if present."

./coding80m/train_stage1.sh auto
./coding80m/train_stage2.sh auto
./coding80m/train_sft.sh auto

if [[ -s data/coding80m/preferences/train.jsonl ]]; then
  ./coding80m/train_dpo.sh auto
else
  echo "[dpo] Skipped: data/coding80m/preferences/train.jsonl is missing or empty."
fi

echo "=== Training pipeline complete ==="
