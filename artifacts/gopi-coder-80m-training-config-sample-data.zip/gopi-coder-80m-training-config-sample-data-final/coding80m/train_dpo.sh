#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
PYTHON="${PYTHON:-.venv/bin/python}"; [[ -x "$PYTHON" ]] || PYTHON=python
export PYTHONPATH="${PYTHONPATH:-}:src"

MODE="${1:-auto}"
LATEST="checkpoints/coding80m/dpo/latest.pt"
SFT_BEST="checkpoints/coding80m/sft/best.pt"

[[ -s "$SFT_BEST" ]] || { echo "[dpo] Missing SFT best checkpoint: $SFT_BEST" >&2; exit 2; }

BASE=(
  "$PYTHON" scripts/train_dpo.py
  --model-config configs/coding80m/model.yaml
  --training-config configs/coding80m/dpo.yaml
  --reference-checkpoint "$SFT_BEST"
)

case "$MODE" in
  auto)
    if [[ -s "$LATEST" ]]; then
      echo "[dpo] Resume checkpoint found: $LATEST"
      exec "${BASE[@]}" --resume "$LATEST"
    fi
    echo "[dpo] No DPO checkpoint found; starting from SFT: $SFT_BEST"
    exec "${BASE[@]}" --init-from "$SFT_BEST"
    ;;
  resume)
    [[ -s "$LATEST" ]] || { echo "[dpo] Cannot resume: $LATEST not found" >&2; exit 2; }
    exec "${BASE[@]}" --resume "$LATEST"
    ;;
  fresh)
    [[ ! -e "$LATEST" ]] || { echo "[dpo] Refusing fresh start while $LATEST exists" >&2; exit 2; }
    exec "${BASE[@]}" --init-from "$SFT_BEST"
    ;;
  *) echo "Usage: $0 [auto|resume|fresh]" >&2; exit 2;;
esac
