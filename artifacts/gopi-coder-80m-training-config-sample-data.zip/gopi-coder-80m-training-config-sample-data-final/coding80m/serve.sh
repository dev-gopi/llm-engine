#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
PYTHON="${PYTHON:-.venv/bin/python}"; [[ -x "$PYTHON" ]] || PYTHON=python
export PYTHONPATH="${PYTHONPATH:-}:src"
export GOPI_INFERENCE_CONFIG="configs/coding80m/inference.yaml"
export GOPI_MODEL_CONFIG="configs/coding80m/model.yaml"
export GOPI_TOKENIZER_PATH="data/coding80m/tokenizer"
# Prefer DPO; fall back to SFT if DPO was skipped.
if [[ -f checkpoints/coding80m/dpo/best.pt ]]; then
  export GOPI_CHECKPOINT_PATH="checkpoints/coding80m/dpo/best.pt"
else
  export GOPI_CHECKPOINT_PATH="checkpoints/coding80m/sft/best.pt"
fi
export GOPI_MODEL_NAME="gopi-coder-80m"
export GOPI_BOT_NAME="GopiCoder"
"$PYTHON" scripts/serve.py --host 127.0.0.1 --port 8000
