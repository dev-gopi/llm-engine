#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
PYTHON="${PYTHON:-.venv/bin/python}"; [[ -x "$PYTHON" ]] || PYTHON=python
export PYTHONPATH="${PYTHONPATH:-}:src"

BACKUP_DIR=".resume-support-backups/$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP_DIR/src/post_training" "$BACKUP_DIR/scripts"

for target in src/post_training/dpo.py scripts/train_dpo.py; do
  [[ -f "$target" ]] || { echo "Missing project file: $target" >&2; exit 2; }
done

cp -a src/post_training/dpo.py "$BACKUP_DIR/src/post_training/dpo.py"
cp -a scripts/train_dpo.py "$BACKUP_DIR/scripts/train_dpo.py"
cp resume_support/src/post_training/dpo.py src/post_training/dpo.py
cp resume_support/scripts/train_dpo.py scripts/train_dpo.py

echo "Installed DPO mid-epoch checkpoint/resume support."
echo "Backup: $BACKUP_DIR"
"$PYTHON" -m py_compile src/post_training/dpo.py scripts/train_dpo.py
