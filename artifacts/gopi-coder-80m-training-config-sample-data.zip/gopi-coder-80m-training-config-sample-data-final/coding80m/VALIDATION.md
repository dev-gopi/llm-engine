# Bundle validation

Validated against `llm-engine-main-hardened-9-target`.

- Model config resolves: PASS
- Exact model parameters: 81,808,128
- Context length: 2,048
- Tokenizer target: 8,192
- Core BPE trainer reached exactly 8,192 vocabulary entries on the included corpus: PASS
- YAML configuration parsing/inheritance: PASS
- Dataset mixture name/weight validation: PASS
- JSONL syntax validation for all included datasets: PASS
- Dataset governance manifests included beside every sample dataset: PASS

The included datasets are synthetic schema/pipeline samples, not a production-scale training corpus.
