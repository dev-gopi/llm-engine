#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
PYTHON="${PYTHON:-.venv/bin/python}"; [[ -x "$PYTHON" ]] || PYTHON=python
export PYTHONPATH="${PYTHONPATH:-}:src"

MODE="${1:-auto}"
LATEST="checkpoints/coding80m/pretrain-stage1/latest.pt"

"$PYTHON" coding80m/verify_vocab.py

case "$MODE" in
  auto)
    if [[ -s "$LATEST" ]]; then
      echo "[stage1] Resume checkpoint found: $LATEST"
      exec "$PYTHON" scripts/train.py \
        --model-config configs/coding80m/model.yaml \
        --training-config configs/coding80m/pretraining.stage1.yaml \
        --resume "$LATEST"
    fi
    echo "[stage1] No checkpoint found; starting fresh."
    exec "$PYTHON" scripts/train.py \
      --model-config configs/coding80m/model.yaml \
      --training-config configs/coding80m/pretraining.stage1.yaml
    ;;
  resume)
    [[ -s "$LATEST" ]] || { echo "[stage1] Cannot resume: $LATEST not found" >&2; exit 2; }
    exec "$PYTHON" scripts/train.py \
      --model-config configs/coding80m/model.yaml \
      --training-config configs/coding80m/pretraining.stage1.yaml \
      --resume "$LATEST"
    ;;
  fresh)
    if [[ -e "$LATEST" ]]; then
      echo "[stage1] Refusing to overwrite an existing checkpoint in fresh mode: $LATEST" >&2
      echo "Move/archive checkpoints/coding80m/pretrain-stage1 first, or use: $0 auto" >&2
      exit 2
    fi
    exec "$PYTHON" scripts/train.py \
      --model-config configs/coding80m/model.yaml \
      --training-config configs/coding80m/pretraining.stage1.yaml
    ;;
  *) echo "Usage: $0 [auto|resume|fresh]" >&2; exit 2;;
esac
