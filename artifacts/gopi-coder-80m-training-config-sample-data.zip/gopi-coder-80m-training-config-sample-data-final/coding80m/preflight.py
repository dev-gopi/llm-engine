from pathlib import Path
import json, yaml
required = [
 'configs/coding80m/model.yaml','configs/coding80m/tokenizer.yaml','configs/coding80m/pretraining.stage1.yaml',
 'configs/coding80m/pretraining.stage2.yaml','configs/coding80m/finetuning.sft.yaml','configs/coding80m/dpo.yaml','configs/coding80m/inference.yaml'
]
for p in required:
    if not Path(p).is_file(): raise SystemExit(f'MISSING: {p}')
for p in Path('data/coding80m').glob('*/train.jsonl'):
    count=0
    with p.open(encoding='utf-8') as f:
        for line in f:
            json.loads(line); count += 1
    print(f'{p}: {count} records')
print('CODING80M PREFLIGHT: PASS')
