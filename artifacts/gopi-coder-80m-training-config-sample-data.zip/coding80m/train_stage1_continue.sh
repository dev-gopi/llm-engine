#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
PYTHON="${PYTHON:-.venv/bin/python}"; [[ -x "$PYTHON" ]] || PYTHON=python
export PYTHONPATH="${PYTHONPATH:-}:src"
"$PYTHON" coding80m/verify_vocab.py
"$PYTHON" scripts/train.py --model-config configs/coding80m/model.yaml --training-config configs/coding80m/pretraining.stage1.continue.yaml --init-from checkpoints/coding80m/pretrain-stage1/best.pt
