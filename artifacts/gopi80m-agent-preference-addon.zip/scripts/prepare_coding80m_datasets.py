#!/usr/bin/env python3
"""Prepare downloaded raw datasets for the GopiCoder-80M training configs.

Input layout (from the config-driven downloader):
    data/coding80m_production/raw/<source>/<subset>/<split>/part-*.jsonl

Output layout (exactly matches gopi-coder-80m-training-config-sample-data-final):
    data/coding80m/
      tokenizer_seed/train.jsonl
      pretrain_code/{train,validation}.jsonl
      pretrain_docs/{train,validation}.jsonl
      pretrain_general/{train,validation}.jsonl
      pretrain_fim/{train,validation}.jsonl
      sft/{train,validation}.jsonl
      agent/{train,validation}.jsonl
      preferences/{train,validation}.jsonl
      */dataset-manifest.yaml

The script streams JSONL, performs conservative normalization/basic quality gates,
exact deduplication backed by SQLite, stable group-aware train/validation splits,
FIM generation from accepted source code, and manifest/stat generation.

It intentionally does NOT claim that raw internet data is legally cleared or
100% correct. Final production release should additionally run approved-license
review, stronger PII/secret scanning, parser/compiler/test validation, near-
deduplication, and benchmark decontamination.
"""

from __future__ import annotations

# Running a file from scripts/ puts scripts/ first on sys.path.  A project file
# named scripts/tokenize.py can shadow Python's stdlib tokenize.  Remove this
# directory before importing third-party modules.
import sys
from pathlib import Path
SCRIPT_DIR = Path(__file__).resolve().parent
if sys.path:
    try:
        if Path(sys.path[0]).resolve() == SCRIPT_DIR:
            sys.path.pop(0)
    except OSError:
        pass

import argparse
import hashlib
import json
import os
import random
import re
import shutil
import sqlite3
import time
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from typing import Any, Iterable, Iterator, Mapping, Sequence
from urllib.parse import urlparse

try:
    import yaml
except ImportError as exc:
    raise SystemExit("Missing dependency: pyyaml. Run: python -m pip install pyyaml") from exc


SYSTEM_PROMPT = (
    "You are GopiCoder, a precise coding assistant. Give correct, concise solutions, "
    "preserve requirements, and mention uncertainty when needed."
)
AGENT_SYSTEM_PROMPT = (
    SYSTEM_PROMPT
    + " Inspect relevant repository context before proposing changes, make the smallest "
      "correct change, and never claim tests passed unless the result explicitly shows it."
)

ROLE_SET = {"system", "user", "assistant", "tool", "developer"}
VENDOR_PARTS = {
    "node_modules", "vendor", "dist", "build", "target", "coverage", ".next",
    "third_party", "__pycache__", ".cache", "site-packages",
}
BAD_SUFFIXES = (".min.js", ".min.css", ".map", ".lock")

# Conservative high-signal credential patterns.  This is not a complete secret scanner.
SECRET_PATTERNS = [
    re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----"),
    re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
    re.compile(r"\bgh[pousr]_[A-Za-z0-9_]{20,}\b"),
    re.compile(r"\b(?:sk|rk)-[A-Za-z0-9_-]{20,}\b"),
    re.compile(r"(?i)\b(?:api[_-]?key|secret|password|passwd|token)\s*[:=]\s*['\"]?[A-Za-z0-9_./+=-]{16,}"),
]
EMAIL_PATTERN = re.compile(r"(?i)\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b")
PHONE_PATTERN = re.compile(r"(?<!\d)(?:\+?\d[\d .()\-]{8,}\d)(?!\d)")


@dataclass
class DatasetStats:
    input_rows: int = 0
    accepted_rows: int = 0
    train_rows: int = 0
    validation_rows: int = 0
    estimated_tokens: int = 0
    rejection_reasons: Counter = field(default_factory=Counter)
    sources: Counter = field(default_factory=Counter)


class JsonlWriter:
    def __init__(self, path: Path):
        self.path = path
        path.parent.mkdir(parents=True, exist_ok=True)
        self.f = path.open("w", encoding="utf-8")
        self.rows = 0
        self.bytes = 0
        self.sha = hashlib.sha256()

    def write(self, obj: Mapping[str, Any]) -> None:
        line = json.dumps(obj, ensure_ascii=False, separators=(",", ":")) + "\n"
        b = line.encode("utf-8")
        self.f.write(line)
        self.sha.update(b)
        self.rows += 1
        self.bytes += len(b)

    def close(self) -> dict[str, Any]:
        self.f.flush()
        os.fsync(self.f.fileno())
        self.f.close()
        return {
            "path": self.path.name,
            "records": self.rows,
            "bytes": self.bytes,
            "sha256": self.sha.hexdigest(),
        }


class ExactDeduper:
    def __init__(self, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(path)
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA synchronous=NORMAL")
        self.db.execute(
            "CREATE TABLE IF NOT EXISTS seen (dataset TEXT NOT NULL, digest TEXT NOT NULL, "
            "PRIMARY KEY(dataset, digest))"
        )
        self.db.commit()
        self.pending = 0

    def add(self, dataset: str, digest: str) -> bool:
        cur = self.db.execute(
            "INSERT OR IGNORE INTO seen(dataset, digest) VALUES (?, ?)", (dataset, digest)
        )
        added = cur.rowcount == 1
        self.pending += 1
        if self.pending >= 5000:
            self.db.commit()
            self.pending = 0
        return added

    def close(self) -> None:
        self.db.commit()
        self.db.close()


def nested(row: Mapping[str, Any], *keys: str) -> Any:
    for key in keys:
        cur: Any = row
        ok = True
        for part in key.split("."):
            if not isinstance(cur, Mapping) or part not in cur:
                ok = False
                break
            cur = cur[part]
        if ok and cur not in (None, "", [], {}):
            return cur
    return None


def as_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, (list, tuple)):
        return "\n".join(as_text(x) for x in value if x is not None)
    if isinstance(value, Mapping):
        return json.dumps(value, ensure_ascii=False)
    return str(value)


def normalize_for_hash(text: str) -> str:
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = "\n".join(line.rstrip() for line in text.splitlines())
    text = re.sub(r"\n{4,}", "\n\n\n", text)
    return text.strip()


def digest_text(text: str) -> str:
    return hashlib.sha256(normalize_for_hash(text).encode("utf-8", errors="replace")).hexdigest()


def estimate_tokens(text: str, chars_per_token: float = 3.5) -> int:
    return max(1, int(len(text) / chars_per_token)) if text else 0


def path_is_vendor(path: str) -> bool:
    clean = path.replace("\\", "/")
    parts = {p.lower() for p in clean.split("/")}
    if parts & VENDOR_PARTS:
        return True
    return clean.lower().endswith(BAD_SUFFIXES)


def has_secret(text: str) -> bool:
    return any(p.search(text) for p in SECRET_PATTERNS)


def redact_pii(text: str, enabled: bool) -> str:
    if not enabled:
        return text
    text = EMAIL_PATTERN.sub("<REDACTED_EMAIL>", text)
    text = PHONE_PATTERN.sub("<REDACTED_PHONE>", text)
    return text


def repeated_line_fraction(text: str) -> float:
    lines = [x.strip() for x in text.splitlines() if x.strip()]
    if len(lines) < 10:
        return 0.0
    counts = Counter(lines)
    repeated = sum(c - 1 for c in counts.values() if c > 1)
    return repeated / max(1, len(lines))


def alpha_fraction(text: str) -> float:
    if not text:
        return 0.0
    return sum(c.isalnum() for c in text) / len(text)


def basic_quality(
    text: str,
    *,
    min_chars: int,
    max_chars: int,
    reject_secrets: bool,
    redact_pii_enabled: bool,
) -> tuple[str | None, str]:
    text = text.replace("\x00", "")
    text = redact_pii(text, redact_pii_enabled)
    n = len(text)
    if n < min_chars:
        return None, "too_short"
    if n > max_chars:
        return None, "too_long"
    if reject_secrets and has_secret(text):
        return None, "secret_detected"
    if alpha_fraction(text) < 0.12:
        return None, "low_alphanumeric_fraction"
    if repeated_line_fraction(text) > 0.35:
        return None, "too_repetitive"
    return text.strip(), "accepted"


def stable_split(group_key: str, validation_ratio: float, seed: int) -> str:
    payload = f"{seed}:{group_key}".encode("utf-8", errors="replace")
    value = int(hashlib.sha256(payload).hexdigest()[:16], 16) / float(0xFFFFFFFFFFFFFFFF)
    return "validation" if value < validation_ratio else "train"


def group_key(row: Mapping[str, Any], text: str) -> str:
    # Repository-level split whenever provenance exists.
    repo = nested(
        row,
        "repo_name", "repository", "repo", "project", "repo_id",
        "_acquisition.repository", "meta.repo_name",
    )
    if repo:
        return "repo:" + as_text(repo)
    url = nested(row, "url", "html_url", "source_url")
    if url:
        parsed = urlparse(as_text(url))
        path_parts = [p for p in parsed.path.split("/") if p]
        if len(path_parts) >= 2:
            return f"urlrepo:{parsed.netloc}/{path_parts[0]}/{path_parts[1]}"
        return f"url:{parsed.netloc}:{parsed.path}"
    return "content:" + digest_text(text)


def source_name(row: Mapping[str, Any], fallback: str) -> str:
    acq = row.get("_acquisition")
    if isinstance(acq, Mapping) and acq.get("source"):
        return str(acq["source"])
    return fallback


def iter_jsonl_files(raw_root: Path) -> Iterator[tuple[str, str, Path]]:
    for path in sorted(raw_root.rglob("*.jsonl")):
        if path.name.startswith("."):
            continue
        try:
            rel = path.relative_to(raw_root)
            source = rel.parts[0] if rel.parts else "unknown"
            split_hint = "validation" if "validation" in rel.parts or "valid" in rel.parts else "train"
        except Exception:
            source, split_hint = "unknown", "train"
        yield source, split_hint, path


def iter_rows(path: Path) -> Iterator[dict[str, Any]]:
    with path.open("r", encoding="utf-8", errors="replace") as f:
        for lineno, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(obj, Mapping):
                yield dict(obj)


def code_from_row(row: Mapping[str, Any]) -> str:
    return as_text(nested(
        row,
        "content", "code", "func_code_string", "solution", "answer", "response",
        "completion", "canonical_solution", "body",
    ))


def docs_from_row(row: Mapping[str, Any]) -> str:
    instruction = as_text(nested(row, "instruction", "problem", "question", "query", "prompt", "title"))
    docs = as_text(nested(
        row,
        "func_documentation_string", "documentation", "docstring", "description", "text", "body",
    ))
    code = as_text(nested(row, "func_code_string", "code", "solution"))
    if instruction and code:
        return f"Instruction:\n{instruction}\n\nCode:\n{code}"
    if docs and code and docs.strip() != code.strip():
        return f"Documentation:\n{docs}\n\nCode:\n{code}"
    return docs or instruction


def general_from_row(row: Mapping[str, Any]) -> str:
    return as_text(nested(row, "text", "content", "body", "description"))


def normalize_messages(value: Any) -> list[dict[str, str]]:
    if not isinstance(value, list):
        return []
    result: list[dict[str, str]] = []
    for item in value:
        if not isinstance(item, Mapping):
            continue
        role = str(item.get("role") or item.get("from") or "").lower().strip()
        if role in {"human", "prompter", "observation"}:
            role = "user"
        elif role in {"gpt", "bot", "model", "ai"}:
            role = "assistant"
        content = item.get("content")
        if content is None:
            content = item.get("value")
        content = as_text(content).strip()
        if role not in ROLE_SET or not content:
            continue
        # Training loader commonly expects user/assistant/system.  Represent tool
        # results as user text when datasets use tool role inconsistently.
        if role == "developer":
            role = "system"
        result.append({"role": role, "content": content})
    return result


def ensure_chat_shape(messages: list[dict[str, str]], *, agent: bool = False) -> list[dict[str, str]]:
    if not messages:
        return []
    out = list(messages)
    if out[0]["role"] != "system":
        out.insert(0, {"role": "system", "content": AGENT_SYSTEM_PROMPT if agent else SYSTEM_PROMPT})
    if not any(m["role"] == "user" for m in out):
        return []
    if not any(m["role"] == "assistant" for m in out):
        return []
    return out



def agent_messages_from_row(
    row: Mapping[str, Any],
    *,
    max_chars: int = 6500,
) -> list[list[dict[str, str]]]:
    """Convert real repository-agent trajectories into context-sized chat windows.

    Supports trajectory as a native list or a JSON-encoded list. Windows preserve
    order, include the system prompt, and never fabricate tool calls/results.
    """
    value = nested(row, "trajectory", "messages", "conversations")
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
            value = parsed
        except json.JSONDecodeError:
            return []

    messages = normalize_messages(value)
    if not messages:
        return []

    # Replace source system prompt with the project agent system prompt while
    # retaining the original task/user/tool/assistant content.
    non_system = [m for m in messages if m["role"] != "system"]
    if not non_system:
        return []

    system = {"role": "system", "content": AGENT_SYSTEM_PROMPT}
    windows: list[list[dict[str, str]]] = []
    current: list[dict[str, str]] = [system]
    current_chars = len(system["content"])

    def useful(chunk: list[dict[str, str]]) -> bool:
        roles = {m["role"] for m in chunk}
        return "assistant" in roles and ("user" in roles or "tool" in roles)

    for msg in non_system:
        msg_chars = len(msg["content"]) + 32
        if current_chars + msg_chars > max_chars and len(current) > 1:
            if useful(current):
                windows.append(current)
            # Keep limited recent context so the next action is not isolated.
            tail = current[-3:] if len(current) > 3 else current[1:]
            current = [system] + tail
            current_chars = sum(len(m["content"]) + 32 for m in current)

        # One huge observation/message can exceed the model context by itself.
        # Keep the beginning and end because agent logs often put commands first
        # and errors/results last.
        content = msg["content"]
        per_message_limit = max(512, int(max_chars * 0.70))
        if len(content) > per_message_limit:
            half = per_message_limit // 2
            content = content[:half] + "\n...[TRUNCATED FOR 2K CONTEXT]...\n" + content[-half:]
            msg = {"role": msg["role"], "content": content}
            msg_chars = len(content) + 32

        current.append(msg)
        current_chars += msg_chars

    if len(current) > 1 and useful(current):
        windows.append(current)

    # Deduplicate identical windows within one long trajectory.
    result: list[list[dict[str, str]]] = []
    seen: set[str] = set()
    for window in windows:
        d = digest_text(chat_text(window))
        if d not in seen:
            seen.add(d)
            result.append(window)
    return result



def sft_from_row(row: Mapping[str, Any], *, agent: bool = False) -> list[dict[str, str]]:
    messages = normalize_messages(nested(row, "messages", "conversations", "chat"))
    if messages:
        return ensure_chat_shape(messages, agent=agent)

    prompt = as_text(nested(
        row, "instruction", "problem", "question", "query", "prompt", "description", "title"
    )).strip()
    answer = as_text(nested(
        row, "output", "answer", "response", "solution", "completion", "code", "accepted_answer"
    )).strip()

    # Some Glaive-style records use a single text conversation.  Keep it for
    # pretraining rather than guessing turns unless explicit fields are present.
    if not prompt or not answer or prompt == answer:
        return []
    return [
        {"role": "system", "content": AGENT_SYSTEM_PROMPT if agent else SYSTEM_PROMPT},
        {"role": "user", "content": prompt},
        {"role": "assistant", "content": answer},
    ]


def preference_from_row(row: Mapping[str, Any]) -> dict[str, str] | None:
    prompt = as_text(nested(row, "prompt", "problem", "instruction", "question", "query")).strip()
    chosen = nested(row, "chosen", "preferred", "better_response", "accepted")
    rejected = nested(row, "rejected", "non_preferred", "worse_response", "rejected_response")

    def response_text(x: Any) -> str:
        if isinstance(x, list):
            msgs = normalize_messages(x)
            assistants = [m["content"] for m in msgs if m["role"] == "assistant"]
            return assistants[-1] if assistants else as_text(x)
        if isinstance(x, Mapping):
            return as_text(x.get("content") or x.get("text") or x)
        return as_text(x)

    c = response_text(chosen).strip()
    r = response_text(rejected).strip()
    if prompt and c and r and c != r:
        return {"prompt": prompt, "chosen": c, "rejected": r}
    return None


def make_fim(text: str, digest: str, min_middle_chars: int = 24) -> str | None:
    # Deterministic syntax-friendly-ish split on line boundaries.  We avoid tiny
    # or one-line snippets because FIM on them is mostly noise.
    lines = text.splitlines(keepends=True)
    if len(lines) < 6 or len(text) < 160:
        return None
    # Stable pseudo-random positions from digest.
    seed = int(digest[:16], 16)
    rng = random.Random(seed)
    n = len(lines)
    start_lo = max(1, n // 10)
    start_hi = max(start_lo + 1, int(n * 0.65))
    start = rng.randrange(start_lo, start_hi)
    max_span = max(1, min(int(n * 0.30), n - start - 1))
    if max_span < 1:
        return None
    span = rng.randint(1, max_span)
    end = min(n - 1, start + span)
    prefix = "".join(lines[:start])
    middle = "".join(lines[start:end])
    suffix = "".join(lines[end:])
    if len(middle.strip()) < min_middle_chars or not prefix.strip() or not suffix.strip():
        return None
    return f"<|fim_prefix|>{prefix}<|fim_suffix|>{suffix}<|fim_middle|>{middle}"


def classify_source(name: str) -> set[str]:
    n = name.lower()
    result: set[str] = set()
    if "fineweb" in n:
        result.add("general")
    if any(x in n for x in ("codeparrot", "stack_v2", "stack-v2", "codesearchnet", "code_search_net")):
        result.add("code")
    if any(x in n for x in ("codesearchnet", "github_issues", "git_commits", "jupyter", "starcoder")):
        result.add("docs")
    if any(x in n for x in ("opencoder", "magicoder", "glaive", "codefeedback", "codeforces")):
        result.add("sft")
    if any(x in n for x in (
        "github_issues", "git_commits", "agent", "trajectory",
        "swe_zero", "swe-zero", "openhands", "swe_agent", "swe-agent",
    )):
        result.add("agent")
    if any(x in n for x in (
        "preference", "dpo", "reward", "codefeedback",
        "code_edit_dpo", "opencode_preference", "security_dpo",
    )):
        result.add("preferences")
    return result


def chat_text(messages: Sequence[Mapping[str, str]]) -> str:
    return "\n".join(f"<{m['role']}>\n{m['content']}" for m in messages)


def manifest_yaml(
    name: str,
    allowed_stages: list[str],
    stats: DatasetStats,
    train_info: Mapping[str, Any] | None,
    validation_info: Mapping[str, Any] | None,
    config: Mapping[str, Any],
) -> dict[str, Any]:
    sources = sorted(stats.sources)
    return {
        "schema_version": 1,
        "name": name,
        "source": "mixed/converted-production-corpus",
        "version": str(config.get("dataset_version", "1")),
        "license": {
            "identifier": "MIXED",
            "review_status": str(config.get("license_review_status", "pending")),
            "commercial_use": config.get("commercial_use", "unknown"),
        },
        "allowed_stages": allowed_stages,
        "privacy_review": str(config.get("privacy_review", "automated-basic")),
        "review_notes": {
            "basis": (
                "Converted from downloaded source datasets. Basic secret/PII/quality gates and exact "
                "deduplication were applied. Original source licenses/provenance remain subject to final "
                "human/legal review; run parser/compiler validation, near-deduplication and benchmark "
                "decontamination before a production/commercial release."
            ),
            "sources": sources,
        },
        "statistics": {
            "input_rows": stats.input_rows,
            "accepted_rows": stats.accepted_rows,
            "train_rows": stats.train_rows,
            "validation_rows": stats.validation_rows,
            "estimated_tokens": stats.estimated_tokens,
            "rejections": dict(stats.rejection_reasons),
        },
        "files": {
            "train": dict(train_info or {}),
            "validation": dict(validation_info or {}),
        },
    }


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--config", default="configs/coding80m-data-prep.yaml")
    p.add_argument("--raw-root", help="Override config raw_root")
    p.add_argument("--output-root", help="Override config output_root")
    p.add_argument("--overwrite", action="store_true")
    p.add_argument("--limit", type=int, default=0, help="Debug: stop after N raw records globally")
    args = p.parse_args()

    cfg = yaml.safe_load(Path(args.config).read_text(encoding="utf-8"))
    if not isinstance(cfg, Mapping):
        raise SystemExit("Top-level config must be a YAML mapping")

    raw_root = Path(args.raw_root or cfg.get("raw_root", "data/coding80m_production/raw"))
    output_root = Path(args.output_root or cfg.get("output_root", "data/coding80m"))
    if not raw_root.exists():
        raise SystemExit(f"Raw dataset root does not exist: {raw_root}")

    if output_root.exists() and any(output_root.iterdir()):
        if not args.overwrite:
            raise SystemExit(
                f"Output directory is not empty: {output_root}\n"
                "Use --overwrite only after backing up any existing training data."
            )
        shutil.rmtree(output_root)
    output_root.mkdir(parents=True, exist_ok=True)

    validation = cfg.get("validation_ratio", {})
    ratios = {
        "pretrain": float(validation.get("pretrain", 0.02)),
        "sft": float(validation.get("sft", 0.05)),
        "agent": float(validation.get("agent", 0.05)),
        "preferences": float(validation.get("preferences", 0.05)),
    }
    seed = int(cfg.get("split_seed", 42))
    q = cfg.get("quality", {})
    min_chars = int(q.get("min_chars", 80))
    max_chars = int(q.get("max_chars", 262144))
    reject_secrets = bool(q.get("reject_secrets", True))
    redact_pii_enabled = bool(q.get("redact_pii", True))
    fim_ratio = float(cfg.get("fim_ratio", 0.20))
    tokenizer_seed_max = int(cfg.get("tokenizer_seed_max_records", 250000))
    agent_max_chars = int(cfg.get("agent_max_chars", 6500))
    preference_max_chars = int(cfg.get("preference_max_chars", 6500))

    dataset_names = [
        "pretrain_code", "pretrain_docs", "pretrain_general", "pretrain_fim",
        "sft", "agent", "preferences",
    ]
    writers: dict[tuple[str, str], JsonlWriter] = {}
    for name in dataset_names:
        for split in ("train", "validation"):
            writers[(name, split)] = JsonlWriter(output_root / name / f"{split}.jsonl")
    tokenizer_writer = JsonlWriter(output_root / "tokenizer_seed" / "train.jsonl")

    stats = {name: DatasetStats() for name in dataset_names}
    deduper = ExactDeduper(output_root / ".prep" / "exact-dedup.sqlite")
    tokenizer_seen = 0
    global_rows = 0

    def emit_text(dataset: str, text: str, row: Mapping[str, Any], src: str, split_hint: str) -> str | None:
        nonlocal tokenizer_seen
        st = stats[dataset]
        st.input_rows += 1
        path_value = as_text(nested(row, "path", "file_path", "filename"))
        if path_value and path_is_vendor(path_value):
            st.rejection_reasons["vendor_or_generated_path"] += 1
            return None
        cleaned, reason = basic_quality(
            text,
            min_chars=min_chars,
            max_chars=max_chars,
            reject_secrets=reject_secrets,
            redact_pii_enabled=redact_pii_enabled,
        )
        if cleaned is None:
            st.rejection_reasons[reason] += 1
            return None
        d = digest_text(cleaned)
        if not deduper.add(dataset, d):
            st.rejection_reasons["exact_duplicate"] += 1
            return None
        split = split_hint if split_hint == "validation" else stable_split(
            group_key(row, cleaned), ratios["pretrain"], seed
        )
        writers[(dataset, split)].write({"text": cleaned})
        st.accepted_rows += 1
        st.sources[src] += 1
        st.estimated_tokens += estimate_tokens(cleaned)
        if split == "train":
            st.train_rows += 1
        else:
            st.validation_rows += 1
        if split == "train" and tokenizer_seen < tokenizer_seed_max:
            # Deterministic sampling gate: roughly one in four accepted examples.
            if int(d[:8], 16) % 4 == 0:
                tokenizer_writer.write({"text": cleaned})
                tokenizer_seen += 1
        return d

    def emit_chat(dataset: str, messages: list[dict[str, str]], row: Mapping[str, Any], src: str, split_hint: str) -> None:
        nonlocal tokenizer_seen
        st = stats[dataset]
        st.input_rows += 1
        if not messages:
            st.rejection_reasons["missing_chat_pair"] += 1
            return
        combined = chat_text(messages)
        cleaned, reason = basic_quality(
            combined,
            min_chars=max(40, min_chars // 2),
            max_chars=(agent_max_chars if dataset == "agent" else max_chars),
            reject_secrets=reject_secrets,
            redact_pii_enabled=redact_pii_enabled,
        )
        if cleaned is None:
            st.rejection_reasons[reason] += 1
            return
        # Apply redaction to each turn rather than storing the joined representation.
        for m in messages:
            m["content"] = redact_pii(m["content"], redact_pii_enabled)
        d = digest_text(chat_text(messages))
        if not deduper.add(dataset, d):
            st.rejection_reasons["exact_duplicate"] += 1
            return
        ratio = ratios["agent"] if dataset == "agent" else ratios["sft"]
        split = split_hint if split_hint == "validation" else stable_split(group_key(row, combined), ratio, seed)
        writers[(dataset, split)].write({"messages": messages})
        st.accepted_rows += 1
        st.sources[src] += 1
        st.estimated_tokens += estimate_tokens(combined)
        if split == "train":
            st.train_rows += 1
        else:
            st.validation_rows += 1
        if split == "train" and tokenizer_seen < tokenizer_seed_max and int(d[:8], 16) % 3 == 0:
            tokenizer_writer.write({"text": combined})
            tokenizer_seen += 1

    def emit_pref(pref: dict[str, str], row: Mapping[str, Any], src: str, split_hint: str) -> None:
        st = stats["preferences"]
        st.input_rows += 1
        combined = pref["prompt"] + "\n" + pref["chosen"] + "\n" + pref["rejected"]
        cleaned, reason = basic_quality(
            combined,
            min_chars=30,
            max_chars=min(max_chars, preference_max_chars),
            reject_secrets=reject_secrets,
            redact_pii_enabled=redact_pii_enabled,
        )
        if cleaned is None:
            st.rejection_reasons[reason] += 1
            return
        for k in ("prompt", "chosen", "rejected"):
            pref[k] = redact_pii(pref[k], redact_pii_enabled)
        d = digest_text(json.dumps(pref, sort_keys=True, ensure_ascii=False))
        if not deduper.add("preferences", d):
            st.rejection_reasons["exact_duplicate"] += 1
            return
        split = split_hint if split_hint == "validation" else stable_split(
            group_key(row, combined), ratios["preferences"], seed
        )
        writers[("preferences", split)].write(pref)
        st.accepted_rows += 1
        st.sources[src] += 1
        st.estimated_tokens += estimate_tokens(combined)
        if split == "train":
            st.train_rows += 1
        else:
            st.validation_rows += 1

    started = time.time()
    for fallback_source, split_hint, path in iter_jsonl_files(raw_root):
        print(f"Processing {path}", flush=True)
        for row in iter_rows(path):
            global_rows += 1
            src = source_name(row, fallback_source)
            classes = classify_source(src)

            if "code" in classes:
                code = code_from_row(row)
                d = emit_text("pretrain_code", code, row, src, split_hint) if code else None
                if d and int(d[:8], 16) / 0xFFFFFFFF < fim_ratio:
                    fim = make_fim(code, d)
                    if fim:
                        emit_text("pretrain_fim", fim, row, src, split_hint)

            if "docs" in classes:
                docs = docs_from_row(row)
                if docs:
                    emit_text("pretrain_docs", docs, row, src, split_hint)

            if "general" in classes:
                text = general_from_row(row)
                if text:
                    emit_text("pretrain_general", text, row, src, split_hint)

            if "sft" in classes:
                msgs = sft_from_row(row, agent=False)
                if msgs:
                    emit_chat("sft", msgs, row, src, split_hint)

            # Only create agent records when there is a genuine issue/commit/agent source
            # and a usable input/output relation.  We do not invent tool trajectories.
            if "agent" in classes:
                windows = agent_messages_from_row(row, max_chars=agent_max_chars)
                if windows:
                    for msgs in windows:
                        emit_chat("agent", msgs, row, src, split_hint)
                else:
                    # Some issue/commit datasets are simple task/answer records
                    # rather than full trajectories. Preserve those when genuine.
                    msgs = sft_from_row(row, agent=True)
                    if msgs:
                        emit_chat("agent", msgs, row, src, split_hint)

            if "preferences" in classes:
                pref = preference_from_row(row)
                if pref:
                    emit_pref(pref, row, src, split_hint)

            if args.limit and global_rows >= args.limit:
                break
        if args.limit and global_rows >= args.limit:
            break

    deduper.close()
    file_infos: dict[tuple[str, str], dict[str, Any]] = {}
    for key, writer in writers.items():
        file_infos[key] = writer.close()
    tokenizer_info = tokenizer_writer.close()

    manifests = {
        "tokenizer_seed": ("Coding80M tokenizer production seed", ["tokenizer"]),
        "pretrain_code": ("Coding80M code pretraining corpus", ["tokenizer", "pretraining"]),
        "pretrain_docs": ("Coding80M technical/code documentation corpus", ["tokenizer", "pretraining"]),
        "pretrain_general": ("Coding80M technical general corpus", ["tokenizer", "pretraining"]),
        "pretrain_fim": ("Coding80M FIM code corpus", ["tokenizer", "pretraining"]),
        "sft": ("Coding80M coding instruction SFT corpus", ["tokenizer", "sft"]),
        "agent": ("Coding80M repository/agent SFT corpus", ["tokenizer", "sft"]),
        "preferences": ("Coding80M preference corpus", ["dpo"]),
    }

    # Tokenizer seed has separate simplified stats.
    tok_stats = DatasetStats(
        accepted_rows=tokenizer_info["records"],
        train_rows=tokenizer_info["records"],
        estimated_tokens=0,
    )
    tok_manifest = manifest_yaml(
        manifests["tokenizer_seed"][0], manifests["tokenizer_seed"][1], tok_stats,
        tokenizer_info, None, cfg,
    )
    (output_root / "tokenizer_seed" / "dataset-manifest.yaml").write_text(
        yaml.safe_dump(tok_manifest, sort_keys=False, allow_unicode=True), encoding="utf-8"
    )

    for dataset in dataset_names:
        title, stages = manifests[dataset]
        manifest = manifest_yaml(
            title,
            stages,
            stats[dataset],
            file_infos[(dataset, "train")],
            file_infos[(dataset, "validation")],
            cfg,
        )
        (output_root / dataset / "dataset-manifest.yaml").write_text(
            yaml.safe_dump(manifest, sort_keys=False, allow_unicode=True), encoding="utf-8"
        )

    summary = {
        "raw_root": str(raw_root),
        "output_root": str(output_root),
        "processed_raw_rows": global_rows,
        "elapsed_seconds": round(time.time() - started, 2),
        "datasets": {
            name: {
                "accepted": st.accepted_rows,
                "train": st.train_rows,
                "validation": st.validation_rows,
                "estimated_tokens": st.estimated_tokens,
                "rejections": dict(st.rejection_reasons),
                "sources": dict(st.sources),
            }
            for name, st in stats.items()
        },
        "tokenizer_seed_rows": tokenizer_info["records"],
    }
    (output_root / "PREPARATION_SUMMARY.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )

    print("\n=== DATASET PREPARATION COMPLETE ===")
    print(f"Raw rows processed: {global_rows:,}")
    for name in dataset_names:
        st = stats[name]
        print(
            f"{name:18s} accepted={st.accepted_rows:,} "
            f"train={st.train_rows:,} validation={st.validation_rows:,} "
            f"est_tokens={st.estimated_tokens:,}"
        )
    print(f"tokenizer_seed     rows={tokenizer_info['records']:,}")
    print(f"Summary: {output_root / 'PREPARATION_SUMMARY.json'}")

    if stats["agent"].accepted_rows == 0:
        print("WARNING: agent dataset is empty. Do not run the configured 28% agent SFT mix until "
              "you add genuine issue/commit/tool/repository trajectories or reduce/remove that weight.")
    if stats["preferences"].accepted_rows == 0:
        print("WARNING: preferences dataset is empty. Skip DPO until you have real chosen/rejected pairs.")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
