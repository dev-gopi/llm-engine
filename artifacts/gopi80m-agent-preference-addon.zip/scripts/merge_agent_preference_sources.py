#!/usr/bin/env python3
"""Append addon `sources` entries to configs/datasets.coding80m.yaml safely."""
from pathlib import Path
import argparse
import yaml

p = argparse.ArgumentParser()
p.add_argument("--base", default="configs/datasets.coding80m.yaml")
p.add_argument("--addon", default="configs/agent-preference-sources.yaml")
args = p.parse_args()

base_path = Path(args.base)
addon_path = Path(args.addon)
base = yaml.safe_load(base_path.read_text())
addon = yaml.safe_load(addon_path.read_text())

base.setdefault("sources", [])
existing = {str(x.get("name")) for x in base["sources"]}
added = 0
for src in addon.get("sources", []):
    if str(src.get("name")) not in existing:
        base["sources"].append(src)
        existing.add(str(src.get("name")))
        added += 1

backup = base_path.with_suffix(base_path.suffix + ".bak")
backup.write_text(base_path.read_text())
base_path.write_text(yaml.safe_dump(base, sort_keys=False))
print(f"Added {added} sources")
print(f"Backup: {backup}")
