#!/usr/bin/env python3

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path


ALLOWED_ROLES = {"system", "user", "assistant", "tool"}


def valid_agent_row(row: dict) -> bool:
    messages = row.get("messages")

    if not isinstance(messages, list) or not messages:
        return False

    has_user = False
    has_assistant = False

    for message in messages:
        if not isinstance(message, dict):
            return False

        role = message.get("role")
        content = message.get("content")

        if role not in ALLOWED_ROLES:
            return False

        if not isinstance(content, str) or not content.strip():
            return False

        if role == "user":
            has_user = True

        if role == "assistant":
            has_assistant = True

    return has_user and has_assistant


def canonical_hash(row: dict) -> str:
    payload = json.dumps(
        row,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    )

    return hashlib.sha256(
        payload.encode("utf-8")
    ).hexdigest()


def repair_file(path: Path) -> dict:
    tmp_path = path.with_suffix(".jsonl.tmp")
    backup_path = path.with_suffix(".jsonl.before-repair")

    total = 0
    accepted = 0
    invalid = 0
    duplicate = 0

    seen: set[str] = set()

    with path.open(
        "r",
        encoding="utf-8",
        errors="replace",
    ) as src, tmp_path.open(
        "w",
        encoding="utf-8",
    ) as dst:

        for line_number, line in enumerate(src, 1):
            line = line.strip()

            if not line:
                continue

            total += 1

            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                invalid += 1
                continue

            if not isinstance(row, dict):
                invalid += 1
                continue

            if not valid_agent_row(row):
                invalid += 1
                continue

            digest = canonical_hash(row)

            if digest in seen:
                duplicate += 1
                continue

            seen.add(digest)

            dst.write(
                json.dumps(
                    row,
                    ensure_ascii=False,
                    separators=(",", ":"),
                )
                + "\n"
            )

            accepted += 1

    if backup_path.exists():
        backup_path.unlink()

    path.rename(backup_path)
    tmp_path.rename(path)

    return {
        "file": str(path),
        "total": total,
        "accepted": accepted,
        "invalid_removed": invalid,
        "duplicates_removed": duplicate,
        "backup": str(backup_path),
    }


def main() -> int:
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--root",
        default="data/coding80m/agent",
    )

    args = parser.parse_args()

    root = Path(args.root)

    results = []

    for split in ("train", "validation"):
        path = root / f"{split}.jsonl"

        if not path.exists():
            raise SystemExit(
                f"Missing file: {path}"
            )

        print(f"Repairing {path} ...")

        result = repair_file(path)

        results.append(result)

        print(
            f"  total={result['total']:,}\n"
            f"  accepted={result['accepted']:,}\n"
            f"  invalid_removed={result['invalid_removed']:,}\n"
            f"  duplicates_removed={result['duplicates_removed']:,}"
        )

    print("\nAGENT DATASET REPAIR COMPLETE")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
