# Add Agent + Preference Data to GopiCoder-80M

Your previous conversion produced `agent=0` and `preferences=0` because ordinary
SFT rows do not contain repository-tool trajectories or chosen/rejected preference
pairs. The converter deliberately did not fabricate either type.

This addon adds real dedicated sources and updates conversion.

## Sources

### Agent
`nvidia/SWE-Zero-openhands-trajectories`

- 318,115 OpenHands software-engineering trajectories.
- Contains `repo`, repository SPDX `license`, full `trajectory`, and `model_patch`.
- Dataset card: CC-BY-4.0 and repository rows limited to MIT/Apache/BSD families.
- The converter windows long trajectories to roughly 6.5K characters because
  GopiCoder-80M has only a 2,048-token context.

### Preferences
`PotatoHD/code-edit-dpo`

- ~29,334 code-editing preference pairs.
- Native `{prompt, chosen, rejected}` schema.
- Mixed/per-item source licenses: keep provenance and filter by your license policy.

`CyberNative/Code_Vulnerability_Security_DPO`

- ~4,660 security/code preference pairs.
- Apache-2.0 dataset card.
- Synthetic, so retain quality checks.

## Install addon

Copy the bundle into project root, then merge the new download sources:

```bash
python scripts/merge_agent_preference_sources.py
```

This backs up your downloader YAML as:

```text
configs/datasets.coding80m.yaml.bak
```

## Download just the new sources

First sample:

```bash
python scripts/download_coding80m_datasets.py \
  --config configs/datasets.coding80m.yaml \
  --profile sample \
  --source nvidia_swe_zero_openhands \
  --source code_edit_dpo \
  --source security_dpo \
  --continue-on-error
```

Then production:

```bash
python scripts/download_coding80m_datasets.py \
  --config configs/datasets.coding80m.yaml \
  --profile production \
  --source nvidia_swe_zero_openhands \
  --source code_edit_dpo \
  --source security_dpo \
  --continue-on-error
```

## Re-run preparation

IMPORTANT: `--overwrite` rebuilds `data/coding80m`, so back it up if you need the
current prepared set. Raw downloads remain under `data/coding80m_production/raw`.

```bash
mv data/coding80m data/coding80m.before-agent-pref

python scripts/prepare_coding80m_datasets.py \
  --config configs/coding80m-data-prep.yaml \
  --overwrite
```

Then validate:

```bash
python scripts/validate_coding80m_prepared.py --root data/coding80m
```

Expected result: both `agent` and `preferences` should be non-zero.

## Quality note

Do not target an exact count before filtering. The 2K model context means long
agent trajectories and long DPO responses must be rejected or windowed. For this
80M model, a smaller high-quality set is better than forcing every raw record in.

Recommended final targets:

- agent windows: ~20K-60K
- preference pairs: ~10K-30K

Always preserve repository/source license metadata before any commercial release.
