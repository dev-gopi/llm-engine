#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
PYTHON="${PYTHON:-.venv/bin/python}"; [[ -x "$PYTHON" ]] || PYTHON=python
export PYTHONPATH="${PYTHONPATH:-}:src"
"$PYTHON" scripts/train.py --model-config configs/coding80m/model.yaml --training-config configs/coding80m/finetuning.sft.yaml --init-from checkpoints/coding80m/pretrain-stage2/best.pt
