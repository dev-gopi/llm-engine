#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
PYTHON="${PYTHON:-.venv/bin/python}"; [[ -x "$PYTHON" ]] || PYTHON=python
export PYTHONPATH="${PYTHONPATH:-}:src"
"$PYTHON" scripts/build_training_report.py --log logs/coding80m-sft.log --output reports/coding80m/final-report.json --model-config configs/coding80m/model.yaml --training-config configs/coding80m/finetuning.sft.yaml --latest-checkpoint checkpoints/coding80m/sft/latest.pt --best-checkpoint checkpoints/coding80m/sft/best.pt
