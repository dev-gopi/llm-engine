#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
PYTHON="${PYTHON:-.venv/bin/python}"; [[ -x "$PYTHON" ]] || PYTHON=python
export PYTHONPATH="${PYTHONPATH:-}:src"
"$PYTHON" scripts/train_dpo.py --model-config configs/coding80m/model.yaml --training-config configs/coding80m/dpo.yaml --reference-checkpoint checkpoints/coding80m/sft/best.pt --init-from checkpoints/coding80m/sft/best.pt
