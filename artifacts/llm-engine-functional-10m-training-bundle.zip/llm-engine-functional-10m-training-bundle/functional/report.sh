#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
PYTHON="${PYTHON:-.venv/bin/python}"
if [[ ! -x "$PYTHON" ]]; then PYTHON="python"; fi
export PYTHONPATH="${PYTHONPATH:-}:src"
"$PYTHON" scripts/build_training_report.py   --log logs/functional-finetuning.log   --output reports/functional/final-report.json   --model-config configs/functional/model.yaml   --training-config configs/functional/finetuning.yaml   --latest-checkpoint checkpoints/functional/finetuning/latest.pt   --best-checkpoint checkpoints/functional/finetuning/best.pt   --watch-seconds 0
cat reports/functional/final-report.json
