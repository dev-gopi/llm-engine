#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")/.."

PYTHON="${PYTHON:-.venv/bin/python}"
if [[ ! -x "$PYTHON" ]]; then
PYTHON="python"
fi

export PYTHONPATH="${PYTHONPATH:-}:src"

export GOPI_INFERENCE_CONFIG="configs/functional/inference.yaml"
export GOPI_MODEL_CONFIG="configs/functional/model.yaml"
export GOPI_TOKENIZER_PATH="data/functional/tokenizer"
export GOPI_CHECKPOINT_PATH="checkpoints/functional/finetuning/best.pt"
export GOPI_MODEL_NAME="gopi-functional-10m"
export GOPI_BOT_NAME="GopiMini"

"$PYTHON" scripts/serve.py \
  --config "${GOPI_INFERENCE_CONFIG}" \
  --host 127.0.0.1 \
  --port 8000
