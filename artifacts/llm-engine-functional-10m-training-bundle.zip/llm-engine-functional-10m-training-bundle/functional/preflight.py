#!/usr/bin/env python3
from __future__ import annotations
import importlib, json, sys
from pathlib import Path
required = ["torch", "yaml", "pyarrow", "regex", "uvicorn", "fastapi"]
missing=[]
for name in required:
    try: importlib.import_module(name)
    except Exception as exc: missing.append((name,str(exc)))
if missing:
    print("FUNCTIONAL PREFLIGHT: FAIL")
    for name,err in missing: print(f"  missing/broken: {name}: {err}")
    print("\nInstall project dependencies first: pip install -e .")
    sys.exit(1)
paths=[
 "configs/functional/tokenizer.yaml","configs/functional/model.yaml",
 "configs/functional/pretraining.yaml","configs/functional/finetuning.yaml",
 "configs/functional/inference.yaml","data/functional/pretrain/train.jsonl",
 "data/functional/pretrain/validation.jsonl","data/functional/sft/train.jsonl",
 "data/functional/sft/validation.jsonl"]
for p in paths:
    if not Path(p).is_file(): raise SystemExit(f"Missing: {p}")
counts={}
for p in paths[-4:]:
    count=0
    for n,line in enumerate(Path(p).read_text(encoding="utf-8").splitlines(),1):
        if line.strip(): json.loads(line); count+=1
    counts[p]=count
print("FUNCTIONAL PREFLIGHT: PASS")
for p,c in counts.items(): print(f"  {p}: {c} records")
