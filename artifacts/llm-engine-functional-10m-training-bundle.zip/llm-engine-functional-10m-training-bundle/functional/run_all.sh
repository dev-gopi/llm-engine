#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
PYTHON="${PYTHON:-.venv/bin/python}"
if [[ ! -x "$PYTHON" ]]; then PYTHON="python"; fi
export PYTHONPATH="${PYTHONPATH:-}:src"

echo '== 0. Preflight =='
"$PYTHON" functional/preflight.py

echo '== 1. Train 2.3K tokenizer =='
rm -rf data/functional/tokenizer
"$PYTHON" scripts/tokenize.py train --config configs/functional/tokenizer.yaml
"$PYTHON" scripts/tokenize.py inspect --tokenizer data/functional/tokenizer   'Hello GopiMini. Explain Python and HTTP.' --add-bos --add-eos
"$PYTHON" functional/verify_vocab.py

echo '== 2. Inspect ~10M model =='
"$PYTHON" scripts/inspect_model.py configs/functional/model.yaml

echo '== 3. Pretraining =='
mkdir -p checkpoints/functional/pretraining checkpoints/functional/finetuning logs reports/functional
"$PYTHON" scripts/train.py   --model-config configs/functional/model.yaml   --training-config configs/functional/pretraining.yaml   --tokenizer data/functional/tokenizer   --output checkpoints/functional/pretraining/latest.pt   --best-output checkpoints/functional/pretraining/best.pt   --log-file logs/functional-pretraining.log   --report-json reports/functional/pretraining.json

echo '== 4. SFT =='
"$PYTHON" scripts/train.py   --model-config configs/functional/model.yaml   --training-config configs/functional/finetuning.yaml   --tokenizer data/functional/tokenizer   --init-from checkpoints/functional/pretraining/best.pt   --output checkpoints/functional/finetuning/latest.pt   --best-output checkpoints/functional/finetuning/best.pt   --log-file logs/functional-finetuning.log   --report-json reports/functional/finetuning.json

echo '== 5. Build report =='
"$PYTHON" scripts/build_training_report.py   --log logs/functional-finetuning.log   --output reports/functional/final-report.json   --model-config configs/functional/model.yaml   --training-config configs/functional/finetuning.yaml   --latest-checkpoint checkpoints/functional/finetuning/latest.pt   --best-checkpoint checkpoints/functional/finetuning/best.pt   --watch-seconds 0

echo 'FUNCTIONAL TRAINING COMPLETE'
echo 'Best checkpoint: checkpoints/functional/finetuning/best.pt'
echo 'Report: reports/functional/final-report.json'
echo 'Serve: ./functional/serve.sh'
