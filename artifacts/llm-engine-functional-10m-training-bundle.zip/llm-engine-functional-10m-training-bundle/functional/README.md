# GopiMini ~10M Functional Training Test

Unzip this bundle into the root of `llm-engine-main-hardened-9-target` (the folder that contains `src/`, `scripts/`, `configs/`, and `pyproject.toml`).

## Included profile

- vocabulary: 4,096 Byte-Level BPE tokens
- model: 6 layers, hidden 256, 8 attention heads, 4 KV heads
- FFN: 1,792 SwiGLU
- context: 512 tokens
- target size: ~10M parameters
- pretraining dataset: 30,000 train + 1,500 validation JSONL records
- SFT dataset: 3,000 train + 300 validation conversations
- pretraining: 2 epochs, 20,000 sampled examples/epoch
- SFT: 3 epochs, all 3,000 examples/epoch

This is a functional learning test, not a production-quality general-purpose model. It is designed to show clearer prompt-dependent behavior than the 354K smoke model.

## Run everything

```bash
source .venv/bin/activate
./functional/run_all.sh
```

The training configs use `mixed_precision: fp16` and the inference config uses CUDA. If your GPU does not support that setup, change training `mixed_precision` to `none` and inference `device` to `cpu` / `weight_dtype` to `float32`.

## Run report

```bash
./functional/report.sh
```

## Serve

```bash
./functional/serve.sh
```

In another terminal:

```bash
source .venv/bin/activate
python functional/chat.py
```

Or:

```bash
curl http://127.0.0.1:8000/v1/models
```

```bash
curl -X POST http://127.0.0.1:8000/v1/chat/completions   -H 'Content-Type: application/json'   -d '{
    "model":"gopi-functional-10m",
    "messages":[{"role":"user","content":"What is Python?"}],
    "max_tokens":128,
    "temperature":0.3
  }'
```

## Useful evaluation prompts

Try these after SFT:

- `Hello`
- `What is Python?`
- `What is HTTP?`
- `What is 17 + 28?`
- `Write Python hello world.`
- `What is a tokenizer?`
- `What is the difference between authentication and authorization?`

Do not expect ChatGPT-level knowledge from a ~10M model. The expected improvement over the tiny smoke model is that responses become prompt-dependent, recognizable, and more coherent on concepts represented in the dataset.

## Vocabulary guarantee

This corrected bundle uses `vocab_size: 2304`. The included synthetic corpus was verified to have enough merge candidates for this target. `functional/run_all.sh` now runs `functional/verify_vocab.py` immediately after tokenizer training and refuses to start pretraining unless the tokenizer vocabulary exactly matches the model vocabulary.

Expected line before pretraining:

```text
VOCAB CHECK: PASS (tokenizer=2304, model=2304)
```

The corrected model remains approximately 10M parameters and is intended only as a functional learning test.
