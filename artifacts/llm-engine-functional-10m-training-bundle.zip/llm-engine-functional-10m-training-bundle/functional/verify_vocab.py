#!/usr/bin/env python3
import json
from pathlib import Path
import yaml

model_cfg = yaml.safe_load(Path('configs/functional/model.yaml').read_text(encoding='utf-8'))
artifact = json.loads(Path('data/functional/tokenizer/tokenizer.json').read_text(encoding='utf-8'))
model_vocab = int(model_cfg['vocab_size'])
tokenizer_vocab = len(artifact['vocab'])
if tokenizer_vocab != model_vocab:
    raise SystemExit(
        f'VOCAB CHECK FAILED: tokenizer={tokenizer_vocab}, model={model_vocab}. '
        'Do not start training until these match.'
    )
print(f'VOCAB CHECK: PASS (tokenizer={tokenizer_vocab}, model={model_vocab})')
