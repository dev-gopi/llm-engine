#!/usr/bin/env python3
from __future__ import annotations
import json, urllib.request
URL="http://127.0.0.1:8000/v1/chat/completions"
print("GopiMini functional test client. Type quit to exit.")
while True:
    try: prompt=input("You> ").strip()
    except (EOFError,KeyboardInterrupt): break
    if prompt.lower() in {"quit","exit"}: break
    body={"model":"gopi-functional-10m","messages":[{"role":"user","content":prompt}],"max_tokens":128,"temperature":0.3}
    req=urllib.request.Request(URL,data=json.dumps(body).encode(),headers={"Content-Type":"application/json"},method="POST")
    try:
        with urllib.request.urlopen(req,timeout=180) as r: data=json.load(r)
        print("GopiMini>",data["choices"][0]["message"]["content"])
    except Exception as exc: print("ERROR:",exc)
