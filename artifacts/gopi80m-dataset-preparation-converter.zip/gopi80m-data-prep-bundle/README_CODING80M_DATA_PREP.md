# GopiCoder-80M — Raw Download → Training Data Converter

This converter was written against the actual schemas and paths in
`gopi-coder-80m-training-config-sample-data-final`.

It creates exactly these files:

```text
data/coding80m/
├── tokenizer_seed/
│   ├── train.jsonl
│   └── dataset-manifest.yaml
├── pretrain_code/
│   ├── train.jsonl
│   ├── validation.jsonl
│   └── dataset-manifest.yaml
├── pretrain_docs/
│   ├── train.jsonl
│   ├── validation.jsonl
│   └── dataset-manifest.yaml
├── pretrain_general/
├── pretrain_fim/
├── sft/
├── agent/
└── preferences/
```

The resulting record contracts match the training bundle:

```json
{"text":"..."}
```
for pretraining/FIM/tokenizer data,

```json
{"messages":[{"role":"system","content":"..."},{"role":"user","content":"..."},{"role":"assistant","content":"..."}]}
```
for SFT/agent data, and

```json
{"prompt":"...","chosen":"...","rejected":"..."}
```
for DPO preference data.

## 1. Install

```bash
source .venv/bin/activate
python -m pip install pyyaml
```

No Hugging Face package is required for this conversion step because it reads
already-downloaded JSONL files.

## 2. Install files

Copy:

```text
scripts/prepare_coding80m_datasets.py
configs/coding80m-data-prep.yaml
```

into your llm-engine project.

## 3. Back up the sample bundle

The converter intentionally refuses to overwrite `data/coding80m` unless you
pass `--overwrite`.

If your sample data is still there:

```bash
mv data/coding80m data/coding80m-sample-backup
```

or explicitly overwrite it after checking your paths.

## 4. Test on only 10,000 raw records

```bash
python scripts/prepare_coding80m_datasets.py \
  --config configs/coding80m-data-prep.yaml \
  --limit 10000 \
  --overwrite
```

Inspect:

```bash
cat data/coding80m/PREPARATION_SUMMARY.json
head -n 2 data/coding80m/pretrain_code/train.jsonl
head -n 2 data/coding80m/sft/train.jsonl
cat data/coding80m/pretrain_code/dataset-manifest.yaml
```

## 5. Full conversion

Delete the debug output or simply rerun with overwrite:

```bash
python scripts/prepare_coding80m_datasets.py \
  --config configs/coding80m-data-prep.yaml \
  --overwrite
```

The script streams files, so it does not load the complete corpus into RAM.
Exact deduplication uses SQLite on disk.

## 6. What goes where

The downloader source names are routed roughly as follows:

| Raw source | Final use |
|---|---|
| `codeparrot_clean` | `pretrain_code` + derived FIM |
| `stack_v2_*` | `pretrain_code` + derived FIM |
| `codesearchnet` | `pretrain_code`, `pretrain_docs`, FIM |
| `fineweb_edu` | `pretrain_general` |
| StarCoder issues/commits/notebooks | `pretrain_docs`; usable issue/commit pairs may also become agent SFT |
| OpenCoder SFT | `sft` |
| Magicoder | `sft` |
| Glaive Code Assistant | `sft` when prompt/answer fields are explicit |
| CodeFeedback instruction | `sft`; DPO only if real chosen/rejected fields exist |
| Codeforces | `sft` when problem + solution are available |

The converter does **not invent fake preference pairs or fake tool traces**.
If downloaded sources contain no real chosen/rejected data, `preferences` may be
empty. If issue/commit data cannot form a real input/output pair, `agent` may be
small or empty. This is intentional.

## 7. Validation split

If the upstream source already lives under a validation split, it stays in
validation. Otherwise a deterministic group-level split is used:

```text
pretraining: 98% train / 2% validation
SFT:         95% train / 5% validation
agent:       95% train / 5% validation
DPO:         95% train / 5% validation
```

Whenever repository metadata exists, the repository is the split key, keeping
all files from the same repo together and reducing leakage.

## 8. FIM generation

`pretrain_fim` is derived only from accepted source-code records. By default,
20% of deduplicated code candidates are selected deterministically and a middle
span is removed on line boundaries:

```text
<|fim_prefix|>PREFIX<|fim_suffix|>SUFFIX<|fim_middle|>MIDDLE
```

This matches the special tokens in `configs/coding80m/tokenizer.yaml`.

## 9. Processing performed

The converter performs:

- source routing
- UTF-8/JSON normalization
- vendor/generated path rejection
- high-signal secret rejection
- basic PII redaction
- length/quality/repetition checks
- exact SHA-256 deduplication using SQLite
- repository/group-stable train/validation splitting
- deterministic FIM derivation
- dataset-manifest generation
- SHA-256 for every final train/validation file
- record/token statistics

## 10. Still required before claiming production-quality data

Do not interpret the output as legally or semantically perfect. Before a final
production/commercial training release, also run:

1. human/legal license allowlist review per source/repository,
2. Gitleaks/TruffleHog or equivalent full secret scanning,
3. stronger PII scan,
4. parser/compiler checks by language,
5. test execution for SFT solutions where tests exist,
6. large-scale near-deduplication (MinHash/LSH),
7. HumanEval/MBPP/SWE-bench/LiveCodeBench/private-eval decontamination,
8. manual random audits.

The generated manifest therefore leaves `license.review_status: pending` by
default instead of falsely claiming review is complete.

## 11. Important SFT config check

Your current `finetuning.sft.yaml` mixes:

```yaml
dataset_weights:
  sft: 0.72
  agent: 0.28
```

If `data/coding80m/agent/train.jsonl` is empty or too small, do **not** train
with that mix. Either collect real agent trajectories or temporarily remove the
agent file and use `sft: 1.0`.

Likewise, run DPO only after `preferences/train.jsonl` contains genuine
chosen/rejected pairs.

## 12. Next commands after conversion

Train tokenizer:

```bash
./coding80m/run_tokenizer.sh
```

Verify vocab:

```bash
python coding80m/verify_vocab.py
```

Inspect model:

```bash
./coding80m/inspect.sh
```

Then Stage 1 pretraining:

```bash
./coding80m/train_stage1.sh
```
