#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
try:
    import yaml
except ImportError:
    raise SystemExit('Install pyyaml: python -m pip install pyyaml')

EXPECTED = {
    'pretrain_code': 'text', 'pretrain_docs': 'text', 'pretrain_general': 'text',
    'pretrain_fim': 'text', 'sft': 'messages', 'agent': 'messages',
    'preferences': 'preference'
}

def validate_row(kind, row):
    if kind == 'text':
        return isinstance(row.get('text'), str) and bool(row['text'].strip())
    if kind == 'messages':
        msgs = row.get('messages')
        return isinstance(msgs, list) and any(isinstance(m, dict) and m.get('role') == 'user' for m in msgs) and any(isinstance(m, dict) and m.get('role') == 'assistant' for m in msgs)
    return all(isinstance(row.get(k), str) and row[k].strip() for k in ('prompt','chosen','rejected')) and row['chosen'] != row['rejected']

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--root', default='data/coding80m')
    ap.add_argument('--sample-rows', type=int, default=1000)
    args=ap.parse_args(); root=Path(args.root)
    errors=[]; warnings=[]
    for name, kind in EXPECTED.items():
        d=root/name
        manifest=d/'dataset-manifest.yaml'
        if not manifest.exists(): errors.append(f'{name}: missing dataset-manifest.yaml')
        else:
            try: yaml.safe_load(manifest.read_text(encoding='utf-8'))
            except Exception as e: errors.append(f'{name}: bad manifest: {e}')
        for split in ('train','validation'):
            p=d/f'{split}.jsonl'
            if not p.exists(): errors.append(f'{name}/{split}: missing file'); continue
            count=0; bad=0
            with p.open(encoding='utf-8', errors='replace') as f:
                for line_no,line in enumerate(f,1):
                    if not line.strip(): continue
                    count += 1
                    if count <= args.sample_rows:
                        try: row=json.loads(line)
                        except Exception:
                            bad += 1; continue
                        if not isinstance(row,dict) or not validate_row(kind,row): bad += 1
            if bad: errors.append(f'{name}/{split}: {bad} invalid sampled rows')
            if count == 0:
                msg=f'{name}/{split}: EMPTY'
                if name in ('preferences','agent'): warnings.append(msg)
                else: warnings.append(msg)
            print(f'{name:18s} {split:10s} rows={count:,}')
    tok=root/'tokenizer_seed'/'train.jsonl'
    if not tok.exists(): errors.append('tokenizer_seed/train.jsonl missing')
    print('\nWarnings:')
    for x in warnings: print('  -',x)
    if errors:
        print('\nFAILED:')
        for x in errors: print('  -',x)
        return 1
    print('\nPREPARED DATA VALIDATION: PASS')
    return 0
if __name__=='__main__': raise SystemExit(main())
