#!/usr/bin/env python3
from __future__ import annotations

import argparse
import codecs
import hashlib
import json
import os
import sys
import time
from pathlib import Path
from typing import Any, Iterable, Mapping

try:
    import yaml
except ImportError as exc:
    raise SystemExit("Missing dependency: pyyaml. Install with: pip install pyyaml") from exc

try:
    from datasets import load_dataset
except ImportError as exc:
    raise SystemExit("Missing dependency: datasets. Install with: pip install 'datasets>=3' huggingface_hub") from exc


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while chunk := f.read(chunk_size):
            h.update(chunk)
    return h.hexdigest()


def json_safe(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    if isinstance(value, Mapping):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(v) for v in value]
    if hasattr(value, "item"):
        try:
            return json_safe(value.item())
        except Exception:
            pass
    return str(value)


def get_nested(row: Mapping[str, Any], key: str) -> Any:
    current: Any = row
    for part in key.split("."):
        if not isinstance(current, Mapping) or part not in current:
            return None
        current = current[part]
    return current


def extract_text(row: Mapping[str, Any], text_fields: list[str]) -> str:
    parts: list[str] = []
    for field in text_fields:
        value = get_nested(row, field)
        if value is None:
            continue
        if isinstance(value, str):
            parts.append(value)
        else:
            parts.append(json.dumps(json_safe(value), ensure_ascii=False))
    return "\n".join(parts)


def estimate_tokens(text: str, chars_per_token: float) -> int:
    if not text:
        return 0
    return max(1, int(len(text) / max(chars_per_token, 0.5)))


def profile_value(value: Any, profile: str, default: Any = None) -> Any:
    if isinstance(value, Mapping):
        return value.get(profile, value.get("default", default))
    return value if value is not None else default


class ShardWriter:
    def __init__(self, directory: Path, max_records: int, max_bytes: int) -> None:
        self.directory = directory
        self.directory.mkdir(parents=True, exist_ok=True)
        self.max_records = max_records
        self.max_bytes = max_bytes
        existing = []
        for path in self.directory.glob("part-*.jsonl"):
            try:
                existing.append(int(path.stem.split("-")[-1]))
            except ValueError:
                pass
        self.index = max(existing, default=-1) + 1
        self.handle = None
        self.tmp_path: Path | None = None
        self.records = 0
        self.bytes_written = 0

    def _open(self) -> None:
        self.tmp_path = self.directory / f".part-{self.index:05d}.jsonl.tmp"
        self.handle = self.tmp_path.open("w", encoding="utf-8")

    def write(self, row: Mapping[str, Any]) -> None:
        if self.handle is None:
            self._open()
        line = json.dumps(json_safe(row), ensure_ascii=False, separators=(",", ":")) + "\n"
        self.handle.write(line)
        self.records += 1
        self.bytes_written += len(line.encode("utf-8"))
        if self.records >= self.max_records or self.bytes_written >= self.max_bytes:
            self.close_shard()

    def close_shard(self) -> None:
        if self.handle is None or self.tmp_path is None:
            return
        self.handle.flush()
        os.fsync(self.handle.fileno())
        self.handle.close()
        final = self.directory / f"part-{self.index:05d}.jsonl"
        self.tmp_path.replace(final)
        print(f"    wrote {final} ({self.records:,} records, {final.stat().st_size / 1e6:.1f} MB)")
        self.index += 1
        self.handle = None
        self.tmp_path = None
        self.records = 0
        self.bytes_written = 0

    def close(self) -> None:
        self.close_shard()


def load_state(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {"rows_seen": 0, "rows_written": 0, "estimated_tokens": 0}
    return json.loads(path.read_text(encoding="utf-8"))


def save_state(path: Path, state: Mapping[str, Any]) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(state, indent=2), encoding="utf-8")
    tmp.replace(path)


def fetch_stack_v2_content(row: Mapping[str, Any], max_blob_bytes: int) -> dict[str, Any]:
    try:
        import boto3
        from smart_open import open as smart_open
    except ImportError as exc:
        raise RuntimeError("Install The Stack v2 extras: pip install boto3 'smart_open[s3]'") from exc

    result = dict(row)
    blob_id = result.get("blob_id")
    encoding = result.get("src_encoding") or "utf-8"
    if not blob_id:
        raise RuntimeError("The Stack v2 row is missing blob_id")

    s3 = boto3.Session().client("s3")
    with smart_open(
        f"s3://softwareheritage/content/{blob_id}",
        "rb",
        compression=".gz",
        transport_params={"client": s3},
    ) as f:
        content = f.read(max_blob_bytes + 1)
    if len(content) > max_blob_bytes:
        raise ValueError("Software Heritage blob is larger than max_blob_bytes")
    try:
        decoder = codecs.getdecoder(str(encoding))
        text, _ = decoder(content, errors="replace")
    except LookupError:
        text = content.decode("utf-8", errors="replace")
    result["content"] = text
    return result


def build_dataset(source: Mapping[str, Any], subset: str | None, split: str, hf_token: str | None):
    kwargs: dict[str, Any] = {
        "path": str(source["repo_id"]),
        "split": split,
        "streaming": bool(source.get("streaming", True)),
    }
    if subset:
        kwargs["name"] = subset
    if source.get("data_dir"):
        kwargs["data_dir"] = str(source["data_dir"])
    if hf_token:
        kwargs["token"] = hf_token
    return load_dataset(**kwargs)


def source_units(source: Mapping[str, Any]):
    subsets = source.get("subsets")
    if subsets:
        for subset in subsets:
            if isinstance(subset, Mapping):
                yield subset.get("name"), str(subset.get("split", source.get("split", "train")))
            else:
                yield str(subset), str(source.get("split", "train"))
    else:
        yield source.get("subset"), str(source.get("split", "train"))


def download_unit(
    source: Mapping[str, Any],
    subset: str | None,
    split: str,
    output_root: Path,
    profile: str,
    hf_token: str | None,
    dry_run: bool,
) -> dict[str, Any]:
    source_name = str(source["name"])
    unit_name = str(subset or source.get("data_dir") or "default")
    safe_unit = unit_name.replace("/", "_").replace(" ", "_")
    out_dir = output_root / source_name / safe_unit / split
    out_dir.mkdir(parents=True, exist_ok=True)

    max_records = profile_value(source.get("max_records"), profile)
    target_tokens = profile_value(source.get("target_estimated_tokens"), profile)
    max_records = int(max_records) if max_records not in (None, 0, "null") else None
    target_tokens = int(target_tokens) if target_tokens not in (None, 0, "null") else None

    if dry_run:
        print(f"DRY-RUN {source_name}/{unit_name}/{split} -> {out_dir}")
        return {"source": source_name, "subset": subset, "split": split, "status": "dry-run"}

    text_fields = [str(v) for v in source.get("text_fields", ["text", "content"])]
    required_fields = [str(v) for v in source.get("required_fields", [])]
    keep_fields = source.get("keep_fields")
    keep_fields = [str(v) for v in keep_fields] if keep_fields else None
    min_chars = int(source.get("min_chars", 1))
    max_chars = source.get("max_chars")
    max_chars = int(max_chars) if max_chars else None
    chars_per_token = float(source.get("chars_per_token", 4.0))

    state_path = out_dir / ".download-state.json"
    state = load_state(state_path)
    rows_seen = int(state.get("rows_seen", 0))
    rows_written = int(state.get("rows_written", 0))
    est_tokens = int(state.get("estimated_tokens", 0))

    print(f"\n== {source_name} / {unit_name} / {split} ==")
    print(f"  output: {out_dir}")
    print(f"  resume: seen={rows_seen:,} written={rows_written:,} est_tokens={est_tokens:,}")

    ds = build_dataset(source, subset, split, hf_token)
    if rows_seen and hasattr(ds, "skip"):
        ds = ds.skip(rows_seen)

    writer = ShardWriter(
        out_dir,
        int(source.get("shard_max_records", 10000)),
        int(source.get("shard_max_bytes", 268435456)),
    )
    rejections: dict[str, int] = {}
    last_save = time.time()
    started = time.time()

    stack_cfg = source.get("software_heritage_s3") or {}
    stack_enabled = bool(stack_cfg.get("enabled", False))
    stack_max_blob = int(stack_cfg.get("max_blob_bytes", 2097152))

    try:
        for raw in ds:
            rows_seen += 1
            row = {str(k): json_safe(v) for k, v in raw.items()}

            if stack_enabled:
                try:
                    row = fetch_stack_v2_content(row, stack_max_blob)
                except Exception as exc:
                    rejections["swh_fetch_failed"] = rejections.get("swh_fetch_failed", 0) + 1
                    print(f"  warning: SWH fetch failed at row {rows_seen}: {exc}", file=sys.stderr)
                    if source.get("fail_on_content_error", False):
                        raise
                    continue

            missing = next((f for f in required_fields if get_nested(row, f) in (None, "", [])), None)
            if missing:
                rejections[f"missing:{missing}"] = rejections.get(f"missing:{missing}", 0) + 1
                continue

            text = extract_text(row, text_fields)
            if len(text) < min_chars:
                rejections["too_short"] = rejections.get("too_short", 0) + 1
                continue
            if max_chars is not None and len(text) > max_chars:
                rejections["too_long"] = rejections.get("too_long", 0) + 1
                continue

            if keep_fields:
                out = {field: json_safe(get_nested(row, field)) for field in keep_fields}
            else:
                out = row
            out["_acquisition"] = {
                "source": source_name,
                "repo_id": str(source["repo_id"]),
                "subset": subset,
                "split": split,
            }
            writer.write(out)
            rows_written += 1
            est_tokens += estimate_tokens(text, chars_per_token)

            if time.time() - last_save >= 15:
                save_state(state_path, {
                    "rows_seen": rows_seen,
                    "rows_written": rows_written,
                    "estimated_tokens": est_tokens,
                })
                print(f"  progress seen={rows_seen:,} written={rows_written:,} est_tokens={est_tokens:,}")
                last_save = time.time()

            if max_records is not None and rows_written >= max_records:
                print("  reached max_records")
                break
            if target_tokens is not None and est_tokens >= target_tokens:
                print("  reached target_estimated_tokens")
                break
    finally:
        writer.close()
        save_state(state_path, {
            "rows_seen": rows_seen,
            "rows_written": rows_written,
            "estimated_tokens": est_tokens,
        })

    shards = []
    for path in sorted(out_dir.glob("part-*.jsonl")):
        shards.append({"file": path.name, "bytes": path.stat().st_size, "sha256": sha256_file(path)})

    manifest = {
        "source": source_name,
        "repo_id": source["repo_id"],
        "subset": subset,
        "split": split,
        "profile": profile,
        "rows_seen": rows_seen,
        "rows_written": rows_written,
        "estimated_tokens": est_tokens,
        "token_estimate_method": f"characters/{chars_per_token:g}",
        "rejections": rejections,
        "source_url": source.get("source_url"),
        "license_note": source.get("license_note"),
        "shards": shards,
        "elapsed_seconds": round(time.time() - started, 3),
    }
    (out_dir / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest


def main() -> int:
    parser = argparse.ArgumentParser(description="Config-driven GopiCoder-80M dataset downloader")
    parser.add_argument("--config", default="configs/datasets.coding80m.yaml")
    parser.add_argument("--profile", choices=("sample", "production"), default="sample")
    parser.add_argument("--source", action="append", help="Only download the named source; repeatable")
    parser.add_argument("--output-root")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--continue-on-error", action="store_true")
    args = parser.parse_args()

    cfg = yaml.safe_load(Path(args.config).read_text(encoding="utf-8"))
    output_root = Path(args.output_root or cfg.get("output_root", "data/coding80m_production/raw"))
    output_root.mkdir(parents=True, exist_ok=True)
    hf_token = os.getenv("HF_TOKEN")
    requested = set(args.source or [])

    sources = cfg.get("sources") or []
    known = {str(s.get("name")) for s in sources}
    unknown = requested - known
    if unknown:
        raise SystemExit(f"Unknown source(s): {', '.join(sorted(unknown))}")

    selected = [
        s for s in sources
        if s.get("enabled", True) and (not requested or str(s.get("name")) in requested)
    ]

    print(f"Config: {args.config}")
    print(f"Profile: {args.profile}")
    print(f"Output root: {output_root}")
    print(f"Enabled sources: {len(selected)}")

    results, failures = [], []
    for source in selected:
        for subset, split in source_units(source):
            try:
                results.append(download_unit(
                    source, subset, split, output_root, args.profile, hf_token, args.dry_run
                ))
            except KeyboardInterrupt:
                print("Interrupted. Resume state was saved.", file=sys.stderr)
                return 130
            except Exception as exc:
                failure = {
                    "source": str(source.get("name")),
                    "subset": str(subset),
                    "split": split,
                    "error": f"{type(exc).__name__}: {exc}",
                }
                failures.append(failure)
                print(f"ERROR: {failure}", file=sys.stderr)
                if not args.continue_on_error:
                    raise

    summary = {
        "profile": args.profile,
        "config": args.config,
        "output_root": str(output_root),
        "completed": results,
        "failures": failures,
    }
    summary_path = output_root / f"download-summary-{args.profile}.json"
    summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(f"Summary: {summary_path}")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
