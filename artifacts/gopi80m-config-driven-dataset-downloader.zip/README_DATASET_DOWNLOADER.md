# GopiCoder-80M Dataset Downloader

This bundle downloads datasets according to `configs/datasets.coding80m.yaml` and writes sharded JSONL under:

```text
data/coding80m_production/raw/<source>/<subset>/<split>/
```

## Install

```bash
source .venv/bin/activate
pip install -U datasets huggingface_hub pyyaml
```

For The Stack v2 Software Heritage content fetching:

```bash
pip install boto3 'smart_open[s3]'
```

## Hugging Face authentication

For gated/private datasets, accept the dataset terms in the browser first, then:

```bash
hf auth login
```

or:

```bash
export HF_TOKEN='hf_...'
```

Never store your token in YAML or Git.

## Dry run

```bash
python scripts/download_coding80m_datasets.py \
  --config configs/datasets.coding80m.yaml \
  --profile sample \
  --dry-run
```

## Safe sample acquisition

```bash
python scripts/download_coding80m_datasets.py \
  --config configs/datasets.coding80m.yaml \
  --profile sample \
  --continue-on-error
```

## One source only

```bash
python scripts/download_coding80m_datasets.py \
  --config configs/datasets.coding80m.yaml \
  --profile sample \
  --source fineweb_edu
```

## Production acquisition

After checking licenses, access rights and disk space:

```bash
python scripts/download_coding80m_datasets.py \
  --config configs/datasets.coding80m.yaml \
  --profile production \
  --continue-on-error
```

The script is resumable. Each output directory contains `.download-state.json`, `manifest.json`, and `part-xxxxx.jsonl` shards with SHA-256 hashes.

## Important

This script performs acquisition plus lightweight min/max-length checks. It does **not** replace your full production filtering pipeline. Before training, run license/provenance gating, generated/vendor/minified removal, secret + PII scanning, parser/compiler validation, exact and near deduplication, benchmark decontamination, quality scoring, and repository-level train/validation splitting.

## The Stack v2

The Stack v2 is disabled by default. Its Hugging Face records contain Software Heritage IDs, and bulk source-content access requires the dataset terms plus a Software Heritage/Inria agreement and AWS credentials. After you have access, enable `stack_v2_python` in YAML and export the required AWS credentials.

## StarCoderData

The issue/commit/notebook entries are also disabled by default because the dataset is gated. Accept its terms and authenticate before enabling those YAML entries.
